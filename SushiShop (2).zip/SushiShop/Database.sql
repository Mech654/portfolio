CREATE TABLE bestillinger (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sushi_type_A_Antal INT,
    sushi_type_B_Antal INT,
    RabatBeløb FLOAT,
    EndeligPris FLOAT
)